const CACHE = 'dane-v1';
const FILES = ['./','./index.html','./manifest.json','./icon-192.png','./icon-512.png','./icon-maskable.png'];

self.addEventListener('install', function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){
    return Promise.all(FILES.map(function(u){ return c.add(u).catch(function(){}); }));
  }).then(function(){ return self.skipWaiting(); }));
});
self.addEventListener('activate', function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.map(function(k){ if(k!==CACHE) return caches.delete(k); }));
  }).then(function(){ return self.clients.claim(); }));
});
self.addEventListener('fetch', function(e){
  if(e.request.method!=='GET') return;
  e.respondWith(fetch(e.request).then(function(r){
    var copy=r.clone();
    caches.open(CACHE).then(function(c){ c.put(e.request,copy).catch(function(){}); });
    return r;
  }).catch(function(){
    return caches.match(e.request).then(function(h){ return h || caches.match('./index.html'); });
  }));
});
